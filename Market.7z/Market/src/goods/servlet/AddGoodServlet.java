package goods.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import goods.bean.Goods;
import goods.service.*;
import java.util.List;
/**
 * Servlet implementation class AddGoodServlet
 */
@WebServlet("/AddGoodServlet")
public class AddGoodServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		Goods a = new Goods();
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String sort=request.getParameter("sort");
		String inprice=request.getParameter("inprice");
		String outprice=request.getParameter("outprice");
		String indate=request.getParameter("indate");
		String baosun=request.getParameter("baosun");
		a.setId(id);
		a.setName(name);
		a.setSort(sort);
		a.setInprice(inprice);
		a.setOutprice(outprice);
		a.setIndate(indate);
		a.setBaosun(baosun);
		Goodservice service = new Goodservice();
		
		try {
			service.insert(a);
			List<Goods> p = service.findAll();
			request.setAttribute("a", p);
			request.getRequestDispatcher("/ShowGoodtempServlet").forward(request, response);
		}
		 catch (Exception e) {
			    e.printStackTrace();
		    }
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
