package goods.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goods.bean.SoldGoods;
import goods.service.SoldService;

/**
 * Servlet implementation class SoldServlet
 */
@WebServlet("/SoldServlet")
public class SoldServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SoldServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String id = request.getParameter("id0").trim(); //.trim()去除前后空格 防止空格的输入
		String outdate = request.getParameter("outdate0");
		double sum=0;//总收银
		SoldService service = new SoldService();
		try {
			List<SoldGoods> list = null;
			list = service.setSold_temp(id, outdate);//取出goods表中该商品的信息，并将其删除，再将该商品销售信息存入sold_0表
			for(int i=0; i<list.size(); i++)
			{
				double mon = Double.parseDouble(list.get(i).getOutprice());
				sum+=mon;
			}
			request.setAttribute("list", list);
			request.setAttribute("sum", sum);
			request.getRequestDispatcher("/Sold.jsp").forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
