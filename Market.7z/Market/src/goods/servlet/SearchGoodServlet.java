package goods.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goods.bean.Goods;
import goods.service.*;
import java.util.List;

/**
 * Servlet implementation class SearchGoodServlet
 */
@WebServlet("/SearchGoodServlet")
public class SearchGoodServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String type = request.getParameter("type");
		String searchtext = request.getParameter("searchtext");
		int count=0;//库存
		Goodservice dao = new Goodservice();
		if(type.equals("商品编号")) {
			try {
				List<Goods> p;
				p = (List<Goods>) dao.findid(searchtext);
				for(int i=0; i<p.size(); i++)
				{
					count=count+1;
				}
				request.setAttribute("count", count);
				request.setAttribute("a", p);		
			    request.getRequestDispatcher("/Goods.jsp").forward(request, response);
			   }catch(Exception e) {
				   e.printStackTrace();
			   }
		}
		else if(type.equals("商品名称")) {
			try {
				List<Goods> p;
				p = (List<Goods>) dao.findname(searchtext);
				for(int i=0; i<p.size(); i++)
				{
					count=count+1;
				}
				request.setAttribute("count", count);
			    request.setAttribute("a", p);
			    request.getRequestDispatcher("/Goods.jsp").forward(request, response);
			   }catch(Exception e) {
				   e.printStackTrace();
			   }
		}
        else if(type.equals("分类")) {
        	try {
        		List<Goods> p;
				p = (List<Goods>) dao.findsort(searchtext);
				for(int i=0; i<p.size(); i++)
				{
					count=count+1;
				}
				request.setAttribute("count", count);
				request.setAttribute("a", p);
 		        request.getRequestDispatcher("/Goods.jsp").forward(request, response);
 		   }catch(Exception e) {
 			   e.printStackTrace();
 		   }
		}
        else if(type.equals("进价")) {
        	try {
        		List<Goods> p;
				p = (List<Goods>) dao.findinprice(searchtext);
				for(int i=0; i<p.size(); i++)
				{
					count=count+1;
				}
				request.setAttribute("count", count);
		        request.setAttribute("a", p);
 		        request.getRequestDispatcher("/Goods.jsp").forward(request, response);
 		   }catch(Exception e) {
 			   e.printStackTrace();
 		   }
		}
        else if(type.equals("售价")) {
        	try {
        		List<Goods> p;
				p = (List<Goods>) dao.findoutprice(searchtext);
				for(int i=0; i<p.size(); i++)
				{
					count=count+1;
				}
				request.setAttribute("count", count);
 		        request.setAttribute("a", p);
 		        request.getRequestDispatcher("/Goods.jsp").forward(request, response);
 		        System.out.print("YES");
 		   }catch(Exception e) {
 			   e.printStackTrace();
 		   }
		}
        else if(type.equals("进货日期")) {
			try {
				List<Goods> p;  	
			    p = (List<Goods>) dao.findindate(searchtext);
			    for(int i=0; i<p.size(); i++)
				{
					count=count+1;
				}
				request.setAttribute("count", count);
			    request.setAttribute("a", p);
			    request.getRequestDispatcher("/Goods.jsp").forward(request, response);
			   }catch(Exception e) {
				   e.printStackTrace();
			   }
		}
        else if(type.equals("所有")){
        	try {
				List<Goods> p;
				p = (List<Goods>) dao.findAllGood();
				for(int i=0; i<p.size(); i++)
				{
					count=count+1;
				}
				request.setAttribute("count", count);
				request.setAttribute("a", p);
			    request.getRequestDispatcher("/Goods.jsp").forward(request, response);
			   }catch(Exception e) {
				   e.printStackTrace();
			   }
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
