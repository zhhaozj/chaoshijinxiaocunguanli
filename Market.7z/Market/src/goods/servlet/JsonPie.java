package goods.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import goods.service.GetType;


/**
 * Servlet implementation class JsonPie
 */
@WebServlet("/JsonPie")
public class JsonPie extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		JSONArray members = new JSONArray();// json对象
		PrintWriter out = response.getWriter();
	
		
		GetType type = new GetType();
		try {
			int t1 = type.type1();
			int t2 = type.type2();
			int t3 = type.type3();
			int t4 = type.type4();
			int t5 = type.type5();
			int t6 = type.type6();

			
			String str[] = new String[6];
			str[0] = "食品类";
			str[1] = "生鲜类";
			str[2] = "洗化类";
			str[3] = "家电";
			str[4] = "文体箱包";
			str[5] = "美妆";
	
			int num[] = new int[6];
			num[0]=t1;
			num[1]=t2;
			num[2]=t3;
			num[3]=t4;
			num[4]=t5;
			num[5]=t6;
			
			String color[]=new String [6];
			color[0] = "#FF0022";
			color[1] = "#f15c80";
			color[2] = "#7cb5ec";
			color[3] = "#8085e8";
			color[4] = "#8d4653";
			color[5] = "#90ed7d";
			for (int i = 0; i <= 5; i++) {
				JSONObject member = new JSONObject();
				// 构建series所需参数
				member.put("name", str[i]); // 对应series.name
				JSONArray list = new JSONArray();// 对应series.data
				list.put(num[i]);
				member.put("year", "种类");// 对应Y轴显示
				member.put("list", list);
				member.put("color", color[i]);//设置柱状图颜色
				members.put(member);

			}
			out.write(members.toString());
			//request.getRequestDispatcher("/admin/pie.jsp").forward(request, response);

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
