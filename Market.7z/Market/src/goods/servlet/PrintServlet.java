package goods.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goods.bean.SoldGoods;
import goods.service.PrintService;

/**
 * Servlet implementation class PrintServlet
 */
@WebServlet("/PrintServlet")
public class PrintServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PrintServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String type = request.getParameter("type");
		String searchtxt = request.getParameter("searchtxt").trim();
		PrintService service = new PrintService();
		
		if(type.equals("商品编号") == true){
			List<SoldGoods> list = null;
			try {
				list = (List<SoldGoods>) service.getSoldid(searchtxt);
				request.setAttribute("list", list);
				request.getRequestDispatcher("/Print.jsp").forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		else if(type.equals("商品名称") == true){
			List<SoldGoods> list = null;
			try {
				list = (List<SoldGoods>) service.getSoldname(searchtxt);
				request.setAttribute("list", list);
				request.getRequestDispatcher("/Print.jsp").forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		else if(type.equals("商品分类") == true){
			List<SoldGoods> list = null;
			try {
				list = (List<SoldGoods>) service.getSoldsort(searchtxt);
				request.setAttribute("list", list);
				request.getRequestDispatcher("/Print.jsp").forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		else if(type.equals("进货日期") == true){
			List<SoldGoods> list = null;
			try {
				list = (List<SoldGoods>) service.getSoldindate(searchtxt);
				request.setAttribute("list", list);
				request.getRequestDispatcher("/Print.jsp").forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		else if(type.equals("销售日期") == true){
			List<SoldGoods> list = null;
			try {
				list = (List<SoldGoods>) service.getSoldoutdate(searchtxt);
				request.setAttribute("list", list);
				request.getRequestDispatcher("/Print.jsp").forward(request, response);
			} catch (SQLException e) {		
				e.printStackTrace();
			}
		}
	}

}
