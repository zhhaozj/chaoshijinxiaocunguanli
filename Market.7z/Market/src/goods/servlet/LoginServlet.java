package goods.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import goods.bean.*;
import goods.service.*;
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		//获得用户名和密码
		String username = request.getParameter("username");
	    String password = request.getParameter("password");
	    System.out.print(username);
	    System.out.print(password);
	    ManagerService service =  new ManagerService();
	    Manager a = new Manager();
	    try {
			a = service.check(username);
			if(a != null && a.getPassword().equals(password))
			{
				request.getSession().setAttribute("manager", a);
				request.getSession().setAttribute("username",a.getUsername() );
				System.out.print("YES");
				request.getRequestDispatcher("/Index.jsp").forward(request, response);
			}
			else
			{
				request.getRequestDispatcher("/ErrorPage.jsp").forward(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
