package goods.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goods.bean.Damage;
import goods.service.DamageService;


/**
 * Servlet implementation class DamageServlet
 */
@WebServlet("/DamageServlet")
public class DamageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DamageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		Damage t = new Damage(null, null, null, null, null, null, null);
		String id=request.getParameter("id2");
		String name=request.getParameter("name2");
		String sort=request.getParameter("sort2");
		String indate=request.getParameter("indate2");
		String baosundate=request.getParameter("baosundate2");
		String fault_description=request.getParameter("fault_description2");
		String applicant=request.getParameter("applicant2");

		t.setId(id);
		t.setName(name);
		t.setSort(sort);
		t.setIndate(indate);
		t.setBaosundate(baosundate);
		t.setFault_description(fault_description);
		t.setApplicant(applicant);
		
		DamageService service = new DamageService();
		try {
	    	service.AddDamage(t);
	    	//修改原商品报损为1
	    	service.ModifyDamage(id);
			request.getRequestDispatcher("/Damage.jsp").forward(request, response);
	    } catch (Exception e) {
		    e.printStackTrace();
	    }
	}

}
