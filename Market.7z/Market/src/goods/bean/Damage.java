package goods.bean;

public class Damage {
	private String id;
    private String name;
    private String sort;
    private String indate;
    private String baosundate;
    private String fault_description;
    private String applicant;
    
    public Damage(String id, String name, String sort, String indate, String baosundate, String fault_description, String applicant){
        this.id=id;
        this.name=name;
        this.sort=sort;
        this.indate=indate;
        this.baosundate=baosundate;
        this.fault_description=fault_description;
        this.applicant=applicant;
    }
    
    public void setId(String id)
    {
        this.id=id;
    }
    public String getId()
    {
        return id;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public String getName()
    {
        return name;
    }
    public void setSort(String sort)
    {
        this.sort=sort;
    }
    public String getSort()
    {
        return sort;
    }
    public void setIndate(String indate)
    {
        this.indate=indate;
    }
    public String getIndate()
    {
        return indate;
    }
    public void setBaosundate(String baosundate)
    {
        this.baosundate=baosundate;
    }
    public String getBaosundate()
    {
        return baosundate;
    }
    public void setFault_description(String fault_description)
    {
        this.fault_description=fault_description;
    }
    public String getFault_description()
    {
        return fault_description;
    }
    public void setApplicant(String applicant)
    {
        this.applicant=applicant;
    }
    public String getApplicant()
    {
        return applicant;
    }
}
