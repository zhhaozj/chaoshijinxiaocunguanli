package goods.bean;

public class Goods {
	private String id;
    private String name;
    private String sort;
    private String inprice;
    private String outprice;
    private String indate;
    private String baosun;

    public Goods(String id, String name, String sort, String inprice, String outprice, String indate, String baosun){
        this.id=id;
        this.name=name;
        this.sort=sort;
        this.inprice=inprice;
        this.outprice=outprice;
        this.indate=indate;
        this.baosun=baosun;
    }
    public Goods() {
    	
    }
    public void setId(String id)
    {
        this.id=id;
    }
    public String getId()
    {
        return id;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public String getName()
    {
        return name;
    }
    public void setSort(String sort)
    {
        this.sort=sort;
    }
    public String getSort()
    {
        return sort;
    }
    public void setInprice(String inprice)
    {
        this.inprice=inprice;
    }
    public String getInprice()
    {
        return inprice;
    }
    public void setOutprice(String outprice)
    {
        this.outprice=outprice;
    }
    public String getOutprice()
    {
        return outprice;
    }
    public void setIndate(String indate)
    {
        this.indate=indate;
    }
    public String getIndate()
    {
        return indate;
    }
    public void setBaosun(String baosun)
    {
        this.baosun=baosun;
    }
    public String getBaosun()
    {
        return baosun;
    }
}
