package goods.bean;

public class SoldGoods {
	private String id;
    private String name;
    private String sort;
    private String indate;
    private String outprice;
    private String outdate;
    
    public SoldGoods(String id, String name, String sort, String indate, String outprice, String outdate){
    this.id=id;
    this.name=name;
    this.sort=sort;
    this.indate=indate;
    this.outprice=outprice;
    this.outdate=outdate;
}

    public SoldGoods() {
        
    }
    public void setId(String id)
    {
        this.id=id;
    }
    public String getId()
    {
        return id;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public String getName()
    {
        return name;
    }
    public void setSort(String sort)
    {
        this.sort=sort;
    }
    public String getSort()
    {
        return sort;
    }
    public void setIndate(String indate)
    {
        this.indate=indate;
    }
    public String getIndate()
    {
        return indate;
    }
    public void setOutprice(String outprice)
    {
        this.outprice=outprice;
    }
    public String getOutprice()
    {
        return outprice;
    }
    public void setOutdate(String outdate)
    {
        this.outdate=outdate;
    }
    public String getOutdate()
    {
        return outdate;
    }
}
