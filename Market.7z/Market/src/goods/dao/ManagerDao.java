package goods.dao;
import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import goods.bean.*;
import goods.utils.*;

public class ManagerDao {
	public Manager check(String username) throws SQLException {
		
	QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
		String sql = "select * from manager where username=?";
		Manager user = (Manager) runner.query(sql,new BeanHandler(Manager.class), new Object[] { username });
		return user;
	}
	
}
