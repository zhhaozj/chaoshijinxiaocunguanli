package goods.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import goods.bean.Damage;
import goods.bean.Goods;
import goods.utils.DBCPConnection;

public class DamageDao {
	
	//根据编号查找商品信息
	public static List<Goods> SearchDamage(String id) throws SQLException {
		QueryRunner runner=new QueryRunner(DBCPConnection.getDataSource());
		String sql = "select * from goods where id = ?";
		List<Goods> list =  runner.query(sql, new BeanListHandler<Goods>(Goods.class),new Object[] {id});
		return list;
	}

	//新建一条报损记录
	public static Object AddDamage(Damage t) throws SQLException {
		//创建QueryRunner对象
		QueryRunner runner=new QueryRunner(DBCPConnection.getDataSource());
		//写SQL语句
		String sql="insert into damage(id,name,sort,indate,baosundate,fault_description,applicant) values(?,?,?,?,?,?,?)";
		//调用方法
		int num=runner.update(sql, new Object[]{
				t.getId(), t.getName(), t.getSort(), t.getIndate(), t.getBaosundate(), t.getFault_description(), t.getApplicant()
		});
		if(num>0) return 1;
		return 0;
	}
	
	//修改原商品信息baosun为1
	public static int ModifyDamage(String id) throws SQLException {
		QueryRunner runner=new QueryRunner(DBCPConnection.getDataSource());
		String sql = "update goods set baosun = ? where id = ?";
		int num=runner.update(sql, new Object[] {"1", id});
		if(num>0) return 1;
		return 0;
		
	}

}
