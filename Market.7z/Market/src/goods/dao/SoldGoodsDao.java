package goods.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import goods.bean.Goods;
import goods.bean.SoldGoods;
import goods.utils.DBCPConnection;

public class SoldGoodsDao {
	
	//取出goods表中该商品的信息，并将其删除，再将该商品销售信息存入sold_temp表
	public static List<SoldGoods> setSold_temp(String id, String outdate) throws SQLException {
		QueryRunner runner1=new QueryRunner(DBCPConnection.getDataSource());
		String sql1 = "select * from goods where id = ?";
		//Goods g =  (Goods) runner1.query(sql1, new BeanListHandler<Goods>(Goods.class),new Object[] {id});
		List<Goods> list1 = runner1.query(sql1, new BeanListHandler<Goods>(Goods.class), id);
		
		String sql2 = "delete from goods where id = ?";
		QueryRunner runner2 = new QueryRunner(DBCPConnection.getDataSource()); 
		runner2.update(sql2, id);
		
		QueryRunner runner3=new QueryRunner(DBCPConnection.getDataSource());
		String sql3="insert into sold_temp(id,name,sort,indate,outprice,outdate) values(?,?,?,?,?,?)";
		int num=runner3.update(sql3, new Object[]{
				list1.get(0).getId(), list1.get(0).getName(), list1.get(0).getSort(), list1.get(0).getIndate(), list1.get(0).getOutprice(), outdate});

		if(num>0)
		{
			String s = "select * from sold_temp";
			List<SoldGoods> list2 = runner3.query(s, new BeanListHandler<SoldGoods>(SoldGoods.class));
			return list2;
		}
		else return null;
	}
	
	//将sold_temp表中信息存入sold表
	public static int setSold() throws SQLException {
		QueryRunner runner=new QueryRunner(DBCPConnection.getDataSource());
		String sql = "select * from sold_temp";
		List<SoldGoods> list = runner.query(sql, new BeanListHandler<SoldGoods>(SoldGoods.class));
		for(int i=0;i<list.size();i++)
		{
		    String sq="insert into sold(id,name,sort,indate,outprice,outdate) values(?,?,?,?,?,?)";
			int num=runner.update(sq, new Object[]{
				list.get(i).getId(), list.get(i).getName(), list.get(i).getSort(), list.get(i).getIndate(),
				list.get(i).getOutprice(), list.get(i).getOutdate()});
		}
		return 1;
	}

	//将sold_temp表清空
	public static int emptySold_temp() throws SQLException {
		QueryRunner runner=new QueryRunner(DBCPConnection.getDataSource());
		String sql = "truncate table sold_temp";
		int num=runner.update(sql);
		return num;
	}
	//遍历全表
    public List<SoldGoods> findAllSold() throws SQLException {
			
		  QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
		
		  String sql = "select * from sold";
		  List<SoldGoods> list = runner.query(sql, new  BeanListHandler<SoldGoods>(SoldGoods.class));
		  return list;
	 }
}
