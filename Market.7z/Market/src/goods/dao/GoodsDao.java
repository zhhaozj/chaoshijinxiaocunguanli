package goods.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;


import goods.bean.Goods;
import goods.utils.*;

public class GoodsDao {
	//查询全部临时表
    public List<Goods> findAll() throws SQLException {
		
		QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
		
		String sql = "select * from goods_add";
		List<Goods> list = runner.query(sql, new  BeanListHandler<Goods>(Goods.class));
		return list;
	}
   //查询全部商品表
    public List<Goods> findAllGood() throws SQLException {
	
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	
	    String sql = "select * from goods";
	    List<Goods> list = runner.query(sql, new  BeanListHandler<Goods>(Goods.class));
	    return list;
    }
   //插入临时表
    public Boolean insert(Goods user) throws SQLException {
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	  
	    String sql = "insert into goods_add (id,name,sort,inprice,outprice,indate,baosun) " +
			"values (?,?,?,?,?,?,?)";
	    int num = runner.update(sql,
			new Object[] { user.getId(), user.getName(),user.getSort(),user.getInprice(),user.getOutprice() ,user.getIndate(),user.getBaosun()});
	    if (num > 0)
		    return true;
	    return false;
     }
    //清空临时表
    public Boolean truncate() throws SQLException {
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	
	    String sql = "truncate table goods_add";
	    int num = runner.update(sql);
	    if (num > 0)
		   return true;
	    return false;
     }
    //将临时表的全部插入goods表
    public Boolean insertAll() throws SQLException {
	
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	
	    String sql = "select * from goods_add";
	    int flag=0;
	    List<Goods> list = runner.query(sql, new  BeanListHandler<Goods>(Goods.class));
	    for(Goods g : list) {
		    String sql1 = "insert into goods (id,name,sort,inprice,outprice,indate,baosun) " +
				"values (?,?,?,?,?,?,?)";
		    int num = runner.update(sql1,new Object[] { g.getId(),g.getName(),g.getSort(),g.getInprice(),g.getOutprice() ,g.getIndate(),g.getBaosun()});
		    if (num > 0)
			   flag=1;
		    else
			   flag=0;
	    }
	    if(flag==1)
		   return true;
	    else
		   return false;
      }
    //按名字查询
    public List<Goods> findname(String name) throws SQLException {
	
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	
	    String sql = "select * from goods where name=?";
	    List<Goods> list = runner.query(sql, new  BeanListHandler<Goods>(Goods.class),name);
	    return list;
     }
    //按id查询
    public List<Goods> findid(String id) throws SQLException {
	
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	
	    String sql = "select * from goods where id=?";
	    List<Goods> list = runner.query(sql, new  BeanListHandler<Goods>(Goods.class),id);
	    return list;
     }
    //按分类查询
    public List<Goods> findsort(String sort) throws SQLException {
	
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	
	    String sql = "select * from goods where sort=?";
	    List<Goods> list = runner.query(sql, new  BeanListHandler<Goods>(Goods.class),sort);
	    return list;
     }
    //按进价查询
    public List<Goods> findinprice(String inprice) throws SQLException {
	
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	
	    String sql = "select * from goods where inprice=?";
	    List<Goods> list = runner.query(sql, new  BeanListHandler<Goods>(Goods.class),inprice);
	    return list;
    }
    //按售价查询
    public List<Goods> findoutprice(String outprice) throws SQLException {
	
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	
	    String sql = "select * from goods where outprice=?";
	    List<Goods> list = runner.query(sql, new  BeanListHandler<Goods>(Goods.class),outprice);
	    return list;
     }
    //按进货日期查询
    public List<Goods> findindate(String indate) throws SQLException {
	
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	
	    String sql = "select * from goods where indate=?";
	    List<Goods> list = runner.query(sql, new  BeanListHandler<Goods>(Goods.class),indate);
	    return list;
     }
    //按id删除
    public Boolean delete(String id) throws SQLException {
	
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	
	    String sql = "delete from goods where id=?";
	
	    int num = runner.update(sql, id);
	    if (num > 0)
		    return true;
	    return false;
     }
    //更新
    public Boolean update(Goods user) throws SQLException {
	
	    QueryRunner runner = new QueryRunner(DBCPConnection.getDataSource());
	
	    String sql = "update  goods set name = ?, sort=?,  inprice=?, outprice=? ,indate=?, baosun=? where id=?";
	
	    int num = runner.update(sql, new Object[] { user.getName(), user.getSort(),user.getInprice(),user.getOutprice(),
                 user.getIndate(), user.getBaosun(), user.getId() });
	    System.out.print("okk");
	    if (num > 0)
		    return true;
	    return false;
     }
}
