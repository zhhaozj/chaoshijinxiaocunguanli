package goods.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import goods.bean.SoldGoods;
import goods.utils.DBCPConnection;

public class PrintDao {

	////按照id查询
	public static List<SoldGoods> getSoldid(String id) throws SQLException {
		QueryRunner runner=new QueryRunner(DBCPConnection.getDataSource());
		String sql = "select * from sold where id = ?";
		List<SoldGoods> list =  runner.query(sql, new BeanListHandler<SoldGoods>(SoldGoods.class),new Object[] {id});
		return list;
	}
	//按照name查询
	public static List<SoldGoods> getSoldname(String name) throws SQLException{
	    QueryRunner runner=new QueryRunner(DBCPConnection.getDataSource());
		String sql = "select * from sold where name = ?";
		List<SoldGoods> list =  runner.query(sql, new BeanListHandler<SoldGoods>(SoldGoods.class),new Object[] {name});
		return list;
	}
	//按照sort查询
	public static List<SoldGoods> getSoldsort(String sort) throws SQLException{
		QueryRunner runner=new QueryRunner(DBCPConnection.getDataSource());
		String sql = "select * from sold where sort = ?";
		List<SoldGoods> list =  runner.query(sql, new BeanListHandler<SoldGoods>(SoldGoods.class),new Object[] {sort});
		return list;
	}
	//按照indate查询
	public static List<SoldGoods> getSoldindate(String indate) throws SQLException{
		QueryRunner runner=new QueryRunner(DBCPConnection.getDataSource());
		String sql = "select * from sold where indate = ?";
		List<SoldGoods> list =  runner.query(sql, new BeanListHandler<SoldGoods>(SoldGoods.class),new Object[] {indate});
		return list;
	}
	//按照outdate查询
	public static List<SoldGoods> getSoldoutdate(String outdate) throws SQLException{
		QueryRunner runner=new QueryRunner(DBCPConnection.getDataSource());
		String sql = "select * from sold where outdate = ?";
		List<SoldGoods> list =  runner.query(sql, new BeanListHandler<SoldGoods>(SoldGoods.class),new Object[] {outdate});
		return list;
	}
}
