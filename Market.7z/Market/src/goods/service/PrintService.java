package goods.service;

import java.sql.SQLException;
import java.util.List;

import goods.bean.SoldGoods;
import goods.dao.PrintDao;

public class PrintService {

	public List<SoldGoods> getSoldid(String id) throws SQLException {
		return PrintDao.getSoldid(id);
	}
	
	public List<SoldGoods> getSoldname(String name) throws SQLException {
		return PrintDao.getSoldname(name);
	}
	
	public List<SoldGoods> getSoldsort(String sort) throws SQLException {
		return PrintDao.getSoldsort(sort);
	}
	
	public List<SoldGoods> getSoldindate(String indate) throws SQLException {
		return PrintDao.getSoldindate(indate);
	}
	
	public List<SoldGoods> getSoldoutdate(String outdate) throws SQLException {
		return PrintDao.getSoldoutdate(outdate);
	}

}
