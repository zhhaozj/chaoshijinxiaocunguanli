package goods.service;
import java.sql.SQLException;
import java.util.List;

import goods.dao.*;
import goods.bean.*;
public class GetType {
	
	public int type1() throws SQLException {
		SoldGoodsDao dao = new SoldGoodsDao();
		int t1=0;
		try {
			List<SoldGoods> list = dao.findAllSold();
			for(SoldGoods p:list){
				if(p.getSort().equals("食品类")){
					t1++;
				}
			}
			return t1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	public int type2() throws SQLException {
		SoldGoodsDao dao = new SoldGoodsDao();
		int t2=0;
		try {
			List<SoldGoods> list = dao.findAllSold();
			for(SoldGoods p:list){
				if(p.getSort().equals("生鲜类")){
					t2++;
				}
			}
			return t2;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	public int type3() throws SQLException {
		SoldGoodsDao dao = new SoldGoodsDao();
		int t3=0;
		try {
			List<SoldGoods> list = dao.findAllSold();
			for(SoldGoods p:list){
				if(p.getSort().equals("洗化类")){
					t3++;
				}
			}
			return t3;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	public int type4() throws SQLException {
		SoldGoodsDao dao = new SoldGoodsDao();
		int t4=0;
		try {
			List<SoldGoods> list = dao.findAllSold();
			for(SoldGoods p:list){
				if(p.getSort().equals("家电")){
					t4++;
				}
			}
			return t4;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	public int type5() throws SQLException {
		SoldGoodsDao dao = new SoldGoodsDao();
		int t5=0;
		try {
			List<SoldGoods> list = dao.findAllSold();
			for(SoldGoods p:list){
				if(p.getSort().equals("文体箱包")){
					t5++;
				}
			}
			return t5;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	public int type6() throws SQLException {
		SoldGoodsDao dao = new SoldGoodsDao();
		int t6=0;
		try {
			List<SoldGoods> list = dao.findAllSold();
			for(SoldGoods p:list){
				if(p.getSort().equals("美妆")){
					t6++;
				}
			}
			return t6;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
}

