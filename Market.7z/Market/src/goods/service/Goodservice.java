package goods.service;
import java.sql.SQLException;
import java.util.List;

import goods.dao.*;
import goods.bean.*;
public class Goodservice {
	private GoodsDao dao = new GoodsDao();
	
	public List<Goods> findAll() throws SQLException {
		try {
			return dao.findAll();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void insert(Goods user) throws SQLException {
		try {
			dao.insert(user);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void truncate() throws SQLException {
		try {
			dao.truncate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void insertAll() throws SQLException {
		try {
			dao.insertAll();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void delete(String id) throws SQLException {
		try {
			dao.delete(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void update(Goods user) throws SQLException {
		try {
			dao.update(user);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public List<Goods> findAllGood() throws SQLException {
		try {
			return dao.findAllGood();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<Goods> findname(String name) throws SQLException {
		try {
			return dao.findname(name);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<Goods> findsort(String sort) throws SQLException {
		try {
			return dao.findsort(sort);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<Goods> findinprice(String inprice) throws SQLException {
		try {
			return dao.findinprice(inprice);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<Goods> findoutprice(String outprice) throws SQLException {
		try {
			return dao.findoutprice(outprice);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<Goods> findindate(String indate) throws SQLException {
		try {
			return dao.findindate(indate);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<Goods> findid(String id) throws SQLException {
		try {
			return dao.findid(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
