package goods.service;
import java.sql.SQLException;

import goods.dao.*;
import goods.bean.*;

public class ManagerService {
	private ManagerDao dao = new  ManagerDao();
	public Manager check(String username) throws SQLException {
		try {
			return dao.check(username);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
