package goods.service;

import java.sql.SQLException;
import java.util.List;

import goods.bean.SoldGoods;
import goods.dao.SoldGoodsDao;

public class SoldService {

	public List<SoldGoods> setSold_temp(String id, String outdate) throws SQLException {
		return SoldGoodsDao.setSold_temp(id, outdate);
	}

	public int setSold() throws SQLException {
		return SoldGoodsDao.setSold();
	}

	public int emptySold_temp() throws SQLException {
		return SoldGoodsDao.emptySold_temp();
	}

}
