package goods.service;

import java.sql.SQLException;
import java.util.List;

import goods.bean.Damage;
import goods.bean.Goods;
import goods.dao.DamageDao;

public class DamageService {	
	
	public List<Goods> SearchDamage(String id) throws SQLException {
		return DamageDao.SearchDamage(id);
	}

	public void AddDamage(Damage t) {
		try {
			DamageDao.AddDamage(t);
		}catch(SQLException e) {
			e.printStackTrace();
		}	
	}

	public int ModifyDamage(String id) throws SQLException {
		return DamageDao.ModifyDamage(id);	
	}

}
